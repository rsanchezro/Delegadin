package com.roberto.delegadin.modelo;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class AlumnoRepositorio {
    private AlumnoDAO alumnoDAO;

    public LiveData<List<Alumno>> getLista_alumnos() {
        return lista_alumnos;
    }

    private LiveData<List<Alumno>> lista_alumnos;


    public AlumnoRepositorio(Application app) {
        AlumnoDatabase a=AlumnoDatabase.getDatabase(app);
        alumnoDAO=a.getAlumnoDAO();
        lista_alumnos=alumnoDAO.obtener_alumnos();
    }

    public void insertar_alumnos(List<Alumno> lista)
    {
        new AsyncTask<List<Alumno>, Void, Void>() {
            @Override
            protected Void doInBackground(List<Alumno>... lists) {
                alumnoDAO.insertar_alumnos(lists[0]);
                return null;
            }
        }.execute(lista);
    }


}
