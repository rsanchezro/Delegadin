package com.roberto.delegadin.modelo;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(foreignKeys ={@ForeignKey(entity =Alumno.class,parentColumns = {"login"},childColumns = {"voto"})})
public class Alumno {
    @PrimaryKey
    private int login;
    private String password;
    private String foto;
    private String descripcion;
    private int voto;

    public Alumno(int login, String password, int voto) {
        this.login = login;
        this.password = password;
        this.voto = voto;
    }

    public int getLogin() {
        return login;
    }

    public void setLogin(int login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getVoto() {
        return voto;
    }

    public void setVoto(int voto) {
        this.voto = voto;
    }
}
