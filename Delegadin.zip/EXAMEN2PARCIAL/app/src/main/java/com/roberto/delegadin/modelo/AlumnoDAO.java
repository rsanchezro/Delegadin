package com.roberto.delegadin.modelo;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface AlumnoDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertar_alumnos(List<Alumno> lista_alumnos);
    @Query("Select * From Alumno")
    public LiveData<List<Alumno>> obtener_alumnos();
}
