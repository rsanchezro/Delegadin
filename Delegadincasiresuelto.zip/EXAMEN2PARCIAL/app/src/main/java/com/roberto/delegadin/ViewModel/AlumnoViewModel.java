package com.roberto.delegadin.ViewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.roberto.delegadin.modelo.Alumno;
import com.roberto.delegadin.modelo.AlumnoRepositorio;

import java.util.List;

public class AlumnoViewModel extends AndroidViewModel {
    private AlumnoRepositorio repositorio;

    public LiveData<List<Alumno>> getAlumnos() {
        return alumnos;
    }

    public void insertar_alumnos(List<Alumno> lista_alumnos)
    {
        repositorio.insertar_alumnos(lista_alumnos);
    }

    private LiveData<List<Alumno>> alumnos;
    public AlumnoViewModel(@NonNull Application application) {
        super(application);
        repositorio=new AlumnoRepositorio(application);
        alumnos=repositorio.getLista_alumnos();

    }


}
