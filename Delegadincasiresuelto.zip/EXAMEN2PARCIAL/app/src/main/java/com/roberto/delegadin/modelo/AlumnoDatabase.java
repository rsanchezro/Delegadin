package com.roberto.delegadin.modelo;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Alumno.class},
        version = 1,
        exportSchema = false)
public abstract class AlumnoDatabase extends RoomDatabase {
    private static AlumnoDatabase INSTANCIA;


    public abstract AlumnoDAO getAlumnoDAO();


    static synchronized AlumnoDatabase
    getDatabase(final Context micontexto)
    {
        if(INSTANCIA==null)
        {
            //Instancio el objeto una sola vez
            INSTANCIA=
                    Room.databaseBuilder(micontexto.getApplicationContext(),
                            AlumnoDatabase.class,"ListaCompra")
                            .build();

        }
        return INSTANCIA;
    }
}
