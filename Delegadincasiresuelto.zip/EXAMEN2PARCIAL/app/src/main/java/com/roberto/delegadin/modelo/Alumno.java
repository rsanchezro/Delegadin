package com.roberto.delegadin.modelo;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(foreignKeys ={@ForeignKey(entity =Alumno.class,parentColumns = {"login"},childColumns = {"voto"})})
public class Alumno {
    @PrimaryKey
    private Integer login;
    private String password;
    private String nombre;
    private String foto;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    private String descripcion;
    private Integer voto=null;



    public Alumno(Integer login, String password, String nombre, String descripcion,String foto) {
        this.login = login;
        this.password = password;
        this.nombre = nombre;
        this.foto = foto;
        this.descripcion = descripcion;
        this.voto=null;


    }




    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public Integer getLogin() {
        return login;
    }

    public void setLogin(Integer login) {
        this.login = login;
    }

    public Integer getVoto() {
        return voto;
    }

    public void setVoto(Integer voto) {
        this.voto = voto;
    }
}
