package com.roberto.delegadin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.ui.AppBarConfiguration;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.roberto.delegadin.ViewModel.AlumnoViewModel;
import com.roberto.delegadin.modelo.Alumno;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    DrawerLayout midrawer;
    NavigationView minavview;
    Toolbar barra;
    ActionBarDrawerToggle toggle;

    AlumnoViewModel listaCompraViewModel;
    public boolean sesioniniciada=false;

    AppBarConfiguration mAppBarConfiguration;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

     listaCompraViewModel = new ViewModelProvider(this).get(AlumnoViewModel.class);


        //Voy a añadir un observador al ViewModel para poder rellenar la tabla productos
        //Es necesario hacerlo en un observador porque no puedo acceder directamente al
        //LIVEDATA, es decir cuando intento acceder al LIVEDATA, al ser un acceso
        /* asincrono, no sé cuando se va a acceder a el, por lo tanto al definir un observador
        cuando se observen cambios en el Livedata (es decir cuando se cargue la base de datos)
        se ejecuta el metodo onchange, y es ahi donde verifico el numero de registros de productos
        si es 0 cargo del fichero JSON
        AL FINALIZAR EL PROCESO ELIMINO EL OBSERVER, PORQUE YA NO ME VA A INTERESAR OBSERVAR
        DESDE AQUI
         */
        listaCompraViewModel.getAlumnos().observe(this, new Observer<List<Alumno>>() {
            @Override
            public void onChanged(List<Alumno> productos) {
                //Se invoca cuando se intentan obtener los productos
                if(productos.size()==0)
                {
                    try {
                        String datos=leerFichero(getAssets().open("candidatos.json"));
                        //Preparo el objeto gson
                        TypeToken<List<Alumno>> tk;
                        ArrayList<Alumno> lista_productos;
                        Gson gson =new Gson();
                        //Necesario generar una clase anonima que extienda de TypeToken pero parametrizada
                        tk=new TypeToken<List<Alumno>>(){};
                        //Convierto el String que representa un Json a un ArrayList de Productos
                        lista_productos=gson.fromJson(datos,tk.getType());

                        listaCompraViewModel.insertar_alumnos(lista_productos);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                //Cuando finalizo elimino el observador
                listaCompraViewModel.getAlumnos().removeObserver(this);
            }
        });
        Toolbar mitoolbar=findViewById(R.id.mitoolbar);
        setSupportActionBar(mitoolbar);
        midrawer=findViewById(R.id.midrawer);
        minavview=findViewById(R.id.minavigationview);

        //Obtengo la cabecera para cambiar el nombre del usuario
        View cabecera=minavview.getHeaderView(0);

        getSupportFragmentManager().beginTransaction().add(R.id.contenedor,new CandidatosFragment(),"candidatos");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ((TextView)(cabecera.findViewById(R.id.usuario_textview_cabecera))).setText("ENTRAR");

        //Asocio a la imagen el inicio de session

        cabecera.findViewById(R.id.imagenAvatar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,LoginActivity.class);
                startActivityForResult(i,1);
            }
        });

        //SE PODRIA PERFECTAMENTE PREPARAR (INFLAR) OTRO MENU AL NAVIGATIONVIEW, en funcion
        //por ejemplo del tipo de usuario que establezca conexion, para hacerlo


        //Limpio el menu que tenga establecido el navview

        // minavview.getMenu().clear();
        //Inflo el nuevo menu
        // minavview.inflateMenu(identificador del recurso menu a inflar);
        //VER DOCUMENTACION https://stackoverflow.com/questions/32649333/changing-navigation-drawer-items-at-runtime
        //Aqui preparo el menu


        //Para que aparece el boton menu hamburguesa y automaticamente se abra el menu lateral
        toggle=new ActionBarDrawerToggle(this,midrawer,barra,R.string.drawer_open,R.string.drawer_close);



        midrawer.addDrawerListener(toggle);
        //Preparo la navegacion del menu
        //Construimos una configuración de la Barra, para asociarsela al drawerlayout, indico
        //las pantallas de navegacion que tienen que tener el mismo valor que el id del menu

        //Con esta función, establecemos vinculación del ActionBar con el Controlador de navegacion, no
        //es imprescindible
        //    NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        //Vincula el controlador con el menu de opciones
        toggle.setDrawerIndicatorEnabled(true);
        toggle.setDrawerSlideAnimationEnabled(true);
        toggle.syncState();



        minavview.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id=menuItem.getItemId();
                int contenedor=R.id.contenedor;
                Fragment fragment=null;
                switch (id)
                {
                    case R.id.candidatos:
                        fragment=new CandidatosFragment();

                        break;
                    case R.id.resultados:
                       fragment=new ResultadoEleccionesFragment();
                        break;
                    case R.id.votar:
                     fragment=new VotarFragment();
                        break;
                    case R.id.cerrarsesion:
                       /*


                        */
                        break;

                }
                if(fragment!=null)
                {
                    getSupportFragmentManager().beginTransaction().replace(contenedor,fragment,"fragmento").commit();
                }

                menuItem.setChecked(true);
                midrawer.closeDrawer(GravityCompat.START);
                return true;
            }

        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home)
        {
            midrawer.openDrawer(GravityCompat.START);

        }
        return true;

    }

    /**
     * Metodo que recibe un fichero como InputStream y devuelve el contenido como String
     * @param fichero
     * @return
     */
    private String leerFichero(InputStream fichero)
    {
        StringBuilder cadena=new StringBuilder("");


        try {
            //Ahora leo del fichero
            BufferedReader entrada=new BufferedReader(new InputStreamReader(fichero));
            String linea;
            linea=entrada.readLine();
            while(linea!=null)
            {
                cadena.append(linea);
                linea=entrada.readLine();
            }
            //Cierro el fichero
            fichero.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return cadena.toString();
    }

}
